
!(function(){

	var doc = document.documentElement;
	var width = doc.clientWidth;
	var fontSize = width / 375 * 50;
	
	doc.style.fontSize = fontSize + 'px';

})()
